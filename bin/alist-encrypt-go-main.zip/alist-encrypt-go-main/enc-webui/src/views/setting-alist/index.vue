<template>
  <div class="scroll-y">
    <h3>Alist服务配置</h3>
    <div v-lang class="mt-30px font-bold mb-10px">服务地址</div>
    <!--条件搜索-->
    <el-form ref="refSearchForm" :label-position="labelPosition" label-width="75px" :model="alistConfigForm">
      <el-form-item prop="username" label="服务器">
        <el-input v-model="alistConfigForm.serverHost" style="max-width: 260px" placeholder="192.168.1.100" />
        <span color="gray" style="font-size: 12px; margin-left: 12px">alist的ip或者域名地址</span>
      </el-form-item>
      <el-form-item prop="password" label="端口">
        <el-input v-model="alistConfigForm.serverPort" style="max-width: 260px" placeholder="5244" />
      </el-form-item>
      <el-form-item prop="https" label="https">
        <el-switch v-model="alistConfigForm.https" class="ml-2" style="--el-switch-on-color: #13ce66; --el-switch-off-color: #ff4949" />
        <span color="gray" style="font-size: 12px; margin-left: 12px">默认http</span>
      </el-form-item>
      <el-form-item prop="enableH2c" label="HTTP/2">
        <el-switch v-model="alistConfigForm.enableH2c" class="ml-2" style="--el-switch-on-color: #13ce66; --el-switch-off-color: #ff4949" />
        <span color="gray" style="font-size: 12px; margin-left: 12px">代理连接后端Alist时启用h2c（需要Alist也开启enable_h2c）</span>
      </el-form-item>
      <el-form-item prop="proxyH2c" label="代理H2C">
        <el-switch v-model="alistConfigForm.proxyH2c" class="ml-2" style="--el-switch-on-color: #13ce66; --el-switch-off-color: #ff4949" />
        <span color="gray" style="font-size: 12px; margin-left: 12px">客户端连接代理时启用h2c（播放器/浏览器需支持）</span>
      </el-form-item>
      <el-form-item prop="enableSizeMap" label="长期映射">
        <el-switch v-model="alistConfigForm.enableSizeMap" class="ml-2" style="--el-switch-on-color: #13ce66; --el-switch-off-color: #ff4949" />
        <span color="gray" style="font-size: 12px; margin-left: 12px">缓存文件大小映射，减少探测请求</span>
      </el-form-item>
      <el-form-item prop="sizeMapTtlMinutes" label="映射TTL">
        <el-input v-model="alistConfigForm.sizeMapTtlMinutes" style="max-width: 260px" placeholder="1440" />
        <span color="gray" style="font-size: 12px; margin-left: 12px">分钟</span>
      </el-form-item>
      <el-form-item prop="enableRangeCompatCache" label="Range兼容">
        <el-switch v-model="alistConfigForm.enableRangeCompatCache" class="ml-2" style="--el-switch-on-color: #13ce66; --el-switch-off-color: #ff4949" />
        <span color="gray" style="font-size: 12px; margin-left: 12px">记录不支持Range的上游并降级</span>
      </el-form-item>
      <el-form-item prop="rangeFailToDowngrade" label="降级阈值">
        <el-input v-model="alistConfigForm.rangeFailToDowngrade" style="max-width: 260px" placeholder="2" />
        <span color="gray" style="font-size: 12px; margin-left: 12px">连续失败次数（1-10）</span>
      </el-form-item>
      <el-form-item prop="rangeSuccessToRecover" label="恢复阈值">
        <el-input v-model="alistConfigForm.rangeSuccessToRecover" style="max-width: 260px" placeholder="3" />
        <span color="gray" style="font-size: 12px; margin-left: 12px">连续成功次数（1-20）</span>
      </el-form-item>
      <el-form-item prop="rangeReprobeMinutes" label="重探间隔">
        <el-input v-model="alistConfigForm.rangeReprobeMinutes" style="max-width: 260px" placeholder="30" />
        <span color="gray" style="font-size: 12px; margin-left: 12px">分钟（1-1440）</span>
      </el-form-item>
      <el-form-item prop="rangeProbeTimeoutSeconds" label="探测超时">
        <el-input v-model="alistConfigForm.rangeProbeTimeoutSeconds" style="max-width: 260px" placeholder="8" />
        <span color="gray" style="font-size: 12px; margin-left: 12px">秒（2-60）</span>
      </el-form-item>
      <el-form-item prop="enableParallelDecrypt" label="并行解密">
        <el-switch v-model="alistConfigForm.enableParallelDecrypt" class="ml-2" style="--el-switch-on-color: #13ce66; --el-switch-off-color: #ff4949" />
        <span color="gray" style="font-size: 12px; margin-left: 12px">大文件分片并行解密</span>
      </el-form-item>
      <el-form-item prop="parallelDecryptConcurrency" label="并发数">
        <el-input v-model="alistConfigForm.parallelDecryptConcurrency" style="max-width: 260px" placeholder="4" />
      </el-form-item>
      <el-form-item prop="streamBufferKb" label="缓冲区KB">
        <el-input v-model="alistConfigForm.streamBufferKb" style="max-width: 260px" placeholder="512" />
      </el-form-item>
      <el-divider content-position="left">代理分流配置</el-divider>
      <el-form-item label="代理模式">
        <el-radio-group v-model="proxyRoutingForm.mode" size="small">
          <el-radio label="direct" border>直连</el-radio>
          <el-radio label="env" border>环境变量</el-radio>
          <el-radio label="fixed" border>固定代理</el-radio>
          <el-radio label="rules" border>规则分流</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="代理地址">
        <el-input v-model="proxyRoutingForm.url" style="max-width: 380px" placeholder="http://host.docker.internal:7890" />
      </el-form-item>
      <el-form-item label="网盘多选">
        <el-select
          v-model="proxyRoutingForm.selectedProviderIDs"
          style="width: 680px"
          multiple
          collapse-tags
          collapse-tags-tooltip
          filterable
          clearable
          placeholder="选择要走代理的网盘（支持多选）"
        >
          <el-option
            v-for="provider in providerOptions"
            :key="provider.id"
            :label="`${provider.provider_name_zh} (${provider.provider_name_en}) [${provider.category}]`"
            :value="provider.id"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="域名预览">
        <el-input v-model="selectedDomainPreview" type="textarea" :rows="4" readonly style="max-width: 680px" />
      </el-form-item>
      <el-form-item label="字典操作">
        <el-button type="primary" plain @click="refreshProviderDictionary">从 OpenList 刷新字典</el-button>
        <span color="gray" style="font-size: 12px; margin-left: 12px">显示中文网盘名，名单外默认直连</span>
      </el-form-item>

      <el-form-item label="密码设置">
        <el-button type="success" @click="addPasswd">添加</el-button>
      </el-form-item>
      <div v-for="(item, index) in alistConfigForm.passwdList" :key="item.id">
        配置 {{ index + 1 }}
        <el-form-item label="算法">
          <el-radio-group v-model="item.encType" style="margin: 0px 5px" size="small">
            <!-- <el-radio label="mix" border>MIX</el-radio> -->
            <el-radio label="aesctr" border>AES-CTR</el-radio>
            <el-radio label="rc4" border>RC4</el-radio>
            <el-radio label="chacha20" border>ChaCha20</el-radio>
          </el-radio-group>
          开启
          <el-switch v-model="item.enable" class="ml-2" style="--el-switch-on-color: #13ce66; --el-switch-off-color: #ff4949" />
          <el-button type="danger" style="margin: 0px 20px" :icon="Delete" circle @click="delPasswd(index)" />
        </el-form-item>
        <el-form-item label="密码">
          <el-input v-model="item.password" style="max-width: 260px; margin-right: 10px" placeholder="12341234" />
        </el-form-item>
        <el-form-item label="文件名">
          加密
          <el-switch v-model="item.encName" class="ml-2" style="margin-right: 10px; --el-switch-on-color: #13ce66; --el-switch-off-color: #ff4949" />
          后缀
          <el-input v-model="item.encSuffix" style="max-width: 150px; margin-left: 10px" placeholder=".bin / 默认原文件名后缀" />
        </el-form-item>
        <el-form-item label="备注">
          <el-input v-model="item.describe" style="max-width: 260px; margin-right: 10px" placeholder="备注描述" />
        </el-form-item>
        <el-form-item label="路径">
          <el-input v-model="item.encPath" style="max-width: 350px; margin-right: 10px" placeholder="多个目录用逗号，隔开" />
          <span color="gray" style="font-size: 13px; margin-left: 12px">example: encrypt/*</span>
        </el-form-item>
        <el-form-item label="子密码:">
          根据文件夹的名字自动识别文件夹的秘钥
          <el-button type="success" size="small" style="margin-left: 10px" @click="checkFoldName(item)">获取</el-button>
        </el-form-item>
        <br />
      </div>
      <el-form-item>
        <el-button type="primary" @click="saveAlistConfig">保存</el-button>
        <el-button type="warning" @click="saveProxyRouting">保存代理分流</el-button>
      </el-form-item>
      <el-dialog v-model="dialogFolderFormVisible" title="获取文件夹密文" style="min-width: 320px">
        <el-tabs v-model="activeName" class="demo-tabs" @tab-click="handleClick">
          <el-tab-pane label="加密名字" name="encode">
            <el-form :model="folderForm">
              <el-form-item prop="username" label="文件夹名称">
                <el-input v-model="folderForm.folderName" style="max-width: 260px" placeholder="folder name" />
              </el-form-item>
              <el-form-item prop="username" label="算法类型">
                <el-radio-group v-model="folderForm.folderEncType" style="margin: 0 15px" size="small">
                  <!-- <el-radio label="mix" border>MIX</el-radio> -->
                  <el-radio label="aesctr" border>AES-CTR</el-radio>
                  <el-radio label="rc4" border>RC4</el-radio>
                  <el-radio label="chacha20" border>ChaCha20</el-radio>
                </el-radio-group>
              </el-form-item>
              <el-form-item prop="username" label="文件夹密码">
                <el-input v-model="folderForm.folderPasswd" style="max-width: 260px" placeholder="123456" />
              </el-form-item>
              <el-form-item prop="username" label="加密结果">
                {{ folderForm.folderNameEnc }}
              </el-form-item>
              <el-button type="success" @click="encodeFoldName">查询</el-button>
            </el-form>
          </el-tab-pane>
          <el-tab-pane label="解密名字" name="decode">
            <el-form :model="folderForm">
              <el-form-item prop="username" label="文件夹名称">
                <el-input v-model="folderForm.folderNameEnc" style="max-width: 260px" placeholder="folder name" />
              </el-form-item>
              <el-form-item prop="username" label="算法类型">
                {{ folderForm.folderEncType }}
              </el-form-item>
              <el-form-item prop="username" label="文件夹密码">
                {{ folderForm.folderPasswd }}
              </el-form-item>
              <el-button type="success" @click="decodeFoldName">解密</el-button>
            </el-form>
          </el-tab-pane>
        </el-tabs>
      </el-dialog>
    </el-form>
  </div>
</template>
<script setup>
import { ref, computed } from 'vue'
import { useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'
import { useConfigStore } from '@/store/config'
import { useBasicStore } from '@/store/basic'
import {
  getAlistConfigReq,
  saveAlistConfigReq,
  encodeFoldNameReq,
  decodeFoldNameReq,
  getSchemeConfigReq,
  saveSchemeConfigReq,
  getProxyDomainDictionaryReq,
  refreshProxyDomainDictionaryReq,
  getProxyRoutingConfigReq,
  saveProxyRoutingConfigReq
} from '@/api/user'

import { Check, Delete, Edit, Message, Search, Star, CirclePlus, Folder } from '@element-plus/icons-vue'
import { random } from 'lodash'

const labelPosition = ref('right')
const dialogFolderFormVisible = ref(false)
const activeName = ref('encode')

const basicStore = useBasicStore()
const { settings, userInfo } = basicStore

const { setLanguage } = useConfigStore()
const route = useRoute()
const changeLanguage = (langParam) => {
  setLanguage(langParam)
}
const folderForm = reactive({
  folderName: 'my video',
  encType: 'aesctr',
  folderPasswd: '123456', // 文件夹密码
  folderNameEnc: '',
  folderEncType: 'rc4',
  password: '' // base password
})

const alistConfigForm = reactive({
  name: '',
  path: '/*',
  describe: '',
  serverHost: '192.168.1.100',
  serverPort: '5244',
  https: false,
  enableH2c: false,
  proxyH2c: false,
  enableSizeMap: true,
  sizeMapTtlMinutes: 1440,
  enableRangeCompatCache: true,
  rangeFailToDowngrade: 2,
  rangeSuccessToRecover: 3,
  rangeReprobeMinutes: 30,
  rangeProbeTimeoutSeconds: 8,
  enableParallelDecrypt: false,
  parallelDecryptConcurrency: 4,
  streamBufferKb: 512,
  passwdList: [
    {
      id: Math.random(),
      password: '123456',
      encType: 'aesctr',
      enable: false,
      encName: false, // encrypt file name
      encSuffix: '', //
      describe: 'my video',
      encPath: '333'
    }
  ]
})
const refSearchForm = ref()
const providerOptions = ref([])

const proxyRoutingForm = reactive({
  mode: 'direct',
  url: '',
  noProxy: [],
  selectedProviderIDs: [],
  selectedDomains: [],
  rules: [],
  dial_timeout_seconds: 30,
  tls_handshake_timeout_seconds: 10,
  response_header_timeout_seconds: 15
})

const collectSelectedDomains = () => {
  const selectedSet = new Set((proxyRoutingForm.selectedProviderIDs || []).map((item) => String(item).toLowerCase()))
  const domains = []
  for (const provider of providerOptions.value) {
    if (!selectedSet.has(String(provider.id).toLowerCase())) {
      continue
    }
    for (const domain of provider.domains || []) {
      domains.push(domain)
    }
  }
  return [...new Set(domains)].sort()
}

const selectedDomainPreview = computed(() => {
  return collectSelectedDomains().join(', ')
})
// 添加密码配置
const addPasswd = () => {
  alistConfigForm.passwdList.push({
    id: Math.random(),
    password: '123456',
    encType: 'aesctr',
    enable: true,
    encName: false,
    encSuffix: '',
    describe: 'my video',
    encPath: '/aliyun/encrypt/*'
  })
}

const delPasswd = (index) => {
  alistConfigForm.passwdList.splice(index, 1)
}
const checkFoldName = (item) => {
  dialogFolderFormVisible.value = true
  folderForm.password = item.password
  folderForm.encType = item.encType
}

const encodeFoldName = async () => {
  const res = await encodeFoldNameReq(folderForm)
  folderForm.folderNameEnc = `${folderForm.folderName}_${res.data.folderNameEnc}`
}

const decodeFoldName = async () => {
  const res = await decodeFoldNameReq(folderForm)
  folderForm.folderPasswd = res.data.folderPasswd
  folderForm.folderEncType = res.data.folderEncType
}

const saveAlistConfig = async () => {
  const toInt = (v, d) => {
    const n = Number.parseInt(v, 10)
    return Number.isFinite(n) ? n : d
  }
  const clamp = (v, min, max) => Math.min(max, Math.max(min, v))
  alistConfigForm.rangeFailToDowngrade = clamp(toInt(alistConfigForm.rangeFailToDowngrade, 2), 1, 10)
  alistConfigForm.rangeSuccessToRecover = clamp(toInt(alistConfigForm.rangeSuccessToRecover, 3), 1, 20)
  alistConfigForm.rangeReprobeMinutes = clamp(toInt(alistConfigForm.rangeReprobeMinutes, 30), 1, 1440)
  alistConfigForm.rangeProbeTimeoutSeconds = clamp(toInt(alistConfigForm.rangeProbeTimeoutSeconds, 8), 2, 60)

  for (const passwdInfo of alistConfigForm.passwdList) {
    if (typeof passwdInfo.encPath === 'string') {
      passwdInfo.encPath = passwdInfo.encPath
        .split(',')
        .map(item => item.trim())
        .filter(item => item.length > 0)
        .join(',')
    }
  }
  // Save alist config
  saveAlistConfigReq(alistConfigForm).then(res => {
    ElMessage.success(res.msg)
  })
  // Save proxy H2C setting separately
  try {
    const schemeRes = await getSchemeConfigReq()
    const schemeData = schemeRes.data || {}
    schemeData.enable_h2c = alistConfigForm.proxyH2c
    await saveSchemeConfigReq(schemeData)
  } catch (err) {
    console.error('Failed to save proxy H2C setting:', err)
  }
}

const loadProxyDictionary = async () => {
  const res = await getProxyDomainDictionaryReq()
  const providers = (res?.data?.providers || []).map((item) => ({
    ...item,
    id: String(item.id || '').toLowerCase()
  }))
  providerOptions.value = providers
  if ((proxyRoutingForm.selectedProviderIDs || []).length === 0) {
    proxyRoutingForm.selectedProviderIDs = providers.filter((item) => item.default_selected).map((item) => item.id)
  }
}

const refreshProviderDictionary = async () => {
  const res = await refreshProxyDomainDictionaryReq()
  const providers = (res?.data?.providers || []).map((item) => ({
    ...item,
    id: String(item.id || '').toLowerCase()
  }))
  providerOptions.value = providers
  ElMessage.success('已刷新网盘字典')
}

const loadProxyRouting = async () => {
  const res = await getProxyRoutingConfigReq()
  if (res?.data) {
    Object.assign(proxyRoutingForm, {
      ...proxyRoutingForm,
      ...res.data,
      selectedProviderIDs: (res.data.selected_provider_ids || res.data.selectedProviderIDs || []).map((item) => String(item).toLowerCase()),
      selectedDomains: res.data.selected_domains || res.data.selectedDomains || []
    })
  }
}

const saveProxyRouting = async () => {
  if (proxyRoutingForm.mode === 'rules' && !proxyRoutingForm.url) {
    ElMessage.error('规则分流模式需要填写代理地址')
    return
  }
  const payload = {
    ...proxyRoutingForm,
    selectedDomains: collectSelectedDomains(),
    selected_provider_ids: proxyRoutingForm.selectedProviderIDs,
    selected_domains: collectSelectedDomains()
  }
  const res = await saveProxyRoutingConfigReq(payload)
  ElMessage.success(res.msg || '保存成功')
}
onMounted(async () => {
  const res = await getAlistConfigReq()
  for (const passwdInfo of res.data.passwdList) {
    passwdInfo.id = Math.random()
    if (Array.isArray(passwdInfo.encPath)) {
      passwdInfo.encPath = passwdInfo.encPath.join(',')
    } else if (typeof passwdInfo.encPath !== 'string') {
      passwdInfo.encPath = ''
    }
  }
  Object.assign(alistConfigForm, res.data)
  // Load proxy H2C setting
  try {
    const schemeRes = await getSchemeConfigReq()
    if (schemeRes.data) {
      alistConfigForm.proxyH2c = schemeRes.data.enable_h2c || false
    }
  } catch (err) {
    console.error('Failed to load proxy H2C setting:', err)
  }
  await loadProxyDictionary()
  await loadProxyRouting()
})
</script>
