//获取用户信息
import axiosReq from '@/utils/axios-req'
export const userInfoReq = () => {
  return new Promise((resolve) => {
    const reqConfig = {
      url: '/enc-api/getUserInfo',
      params: { plateFormId: 2 },
      method: 'post'
    }
    axiosReq(reqConfig).then(({ data }) => {
      resolve(data)
    })
  })
}
// 更新密码
export const upatePasswordReq = (subForm) => {
  return axiosReq({
    url: '/enc-api/updatePasswd',
    data: subForm,
    method: 'post'
  })
}

// 更新用户名
export const updateUsernameReq = (subForm) => {
  return axiosReq({
    url: '/enc-api/updateUsername',
    data: subForm,
    method: 'post'
  })
}
// 获取alist的配置信息
export const getAlistConfigReq = (subForm) => {
  return axiosReq({
    url: '/enc-api/getAlistConfig',
    data: subForm,
    method: 'post'
  })
}
// 保存信息
export const saveAlistConfigReq = (subForm) => {
  return axiosReq({
    url: '/enc-api/saveAlistConfig',
    data: subForm,
    method: 'post'
  })
}

// 获取webdav配置信息
export const getWebdavConfigReq = (subForm) => {
  return axiosReq({
    url: '/enc-api/getWebdavonfig',
    data: subForm,
    method: 'post'
  })
}

export const saveWebdavConfigReq = (subForm) => {
  return axiosReq({
    url: '/enc-api/saveWebdavConfig',
    data: subForm,
    method: 'post'
  })
}
export const updateWebdavConfigReq = (subForm) => {
  return axiosReq({
    url: '/enc-api/updateWebdavConfig',
    data: subForm,
    method: 'post'
  })
}

export const delWebdavConfigReq = (subForm) => {
  return axiosReq({
    url: '/enc-api/delWebdavConfig',
    data: subForm,
    method: 'post'
  })
}

export const encodeFoldNameReq = (subForm) => {
  return axiosReq({
    url: '/enc-api/encodeFoldName',
    data: subForm,
    method: 'post'
  })
}

export const decodeFoldNameReq = (subForm) => {
  return axiosReq({
    url: '/enc-api/decodeFoldName',
    data: subForm,
    method: 'post'
  })
}

export const checkFilePathReq = (subForm) => {
  return axiosReq({
    url: '/enc-api/checkFilePath',
    data: subForm,
    method: 'post'
  })
}
export const encryptFileReq = (subForm) => {
  return axiosReq({
    url: '/enc-api/encryptFile',
    data: subForm,
    method: 'post'
  })
}

// login
export const loginReq = (subForm) => {
  return axiosReq({
    url: '/enc-api/login',
    data: subForm,
    method: 'post'
  })
}

//退出登录
export const loginOutReq = () => {
  return axiosReq({
    url: '/mock/basis-func/user/loginValid',
    method: 'post'
  })
}

// 获取服务器scheme配置
export const getSchemeConfigReq = () => {
  return axiosReq({
    url: '/enc-api/getSchemeConfig',
    method: 'post'
  })
}

// 保存服务器scheme配置
export const saveSchemeConfigReq = (subForm) => {
  return axiosReq({
    url: '/enc-api/saveSchemeConfig',
    data: subForm,
    method: 'post'
  })
}

export const getProxyDomainDictionaryReq = () => {
  return axiosReq({
    url: '/enc-api/getProxyDomainDictionary',
    method: 'post'
  })
}

export const refreshProxyDomainDictionaryReq = () => {
  return axiosReq({
    url: '/enc-api/refreshProxyDomainDictionary',
    method: 'post'
  })
}

export const getProxyRoutingConfigReq = () => {
  return axiosReq({
    url: '/enc-api/getProxyRoutingConfig',
    method: 'post'
  })
}

export const saveProxyRoutingConfigReq = (subForm) => {
  return axiosReq({
    url: '/enc-api/saveProxyRoutingConfig',
    data: subForm,
    method: 'post'
  })
}
