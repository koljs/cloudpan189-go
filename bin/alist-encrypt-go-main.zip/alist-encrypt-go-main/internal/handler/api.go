package handler

import (
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"net/http"
	"path/filepath"
	"strconv"
	"strings"
	"sync/atomic"
	"time"

	"github.com/alist-encrypt-go/internal/auth"
	"github.com/alist-encrypt-go/internal/config"
	"github.com/alist-encrypt-go/internal/dao"
	"github.com/alist-encrypt-go/internal/encryption"
	"github.com/alist-encrypt-go/internal/proxydict"
	"github.com/alist-encrypt-go/internal/restart"
	"github.com/alist-encrypt-go/internal/storage/mysqlstore"
	"github.com/rs/zerolog/log"
)

// APIHandler handles /enc-api/* routes
type APIHandler struct {
	cfg        *config.Config
	jwtAuth    *auth.JWTAuth
	userDAO    *dao.UserDAO
	passwdDAO  *dao.PasswdDAO
	mysqlStore *mysqlstore.Store
	dictMgr    *proxydict.Manager
}

var deprecatedRangeCompatTTLWarned uint32

// NewAPIHandler creates a new API handler
func NewAPIHandler(cfg *config.Config, userDAO *dao.UserDAO, passwdDAO *dao.PasswdDAO, mysqlStore *mysqlstore.Store) *APIHandler {
	expireHours := cfg.JWTExpire
	if expireHours <= 0 {
		expireHours = 48
	}
	return &APIHandler{
		cfg:        cfg,
		jwtAuth:    auth.NewJWTAuth(cfg.JWTSecret, time.Duration(expireHours)*time.Hour),
		userDAO:    userDAO,
		passwdDAO:  passwdDAO,
		mysqlStore: mysqlStore,
		dictMgr:    proxydict.NewManager(filepath.Join("conf", "proxy_domain_dict.json"), filepath.Join("configs", "proxy_domain_dict.seed.json")),
	}
}

// Login handles user authentication
func (h *APIHandler) Login(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Username string `json:"username"`
		Password string `json:"password"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		RespondAPIError(w, 500, "Invalid request")
		return
	}

	if err := h.userDAO.Validate(req.Username, req.Password); err != nil {
		// Match Node.js error message exactly: "passwword error" (note the typo in original)
		RespondAPIError(w, 500, "passwword error")
		return
	}

	token, err := h.jwtAuth.GenerateToken(req.Username)
	if err != nil {
		RespondAPIError(w, 500, "token generate failed")
		return
	}

	RespondSuccess(w, map[string]interface{}{
		"userInfo": map[string]interface{}{
			"username":   req.Username,
			"headImgUrl": "/public/logo.svg",
		},
		"jwtToken": token,
	})
}

// GetUserInfo returns current user info
func (h *APIHandler) GetUserInfo(w http.ResponseWriter, r *http.Request) {
	// Get actual username from database
	user, err := h.userDAO.GetFirstUser()
	username := "admin"
	if err == nil && user != nil {
		username = user.Username
	}

	RespondSuccess(w, map[string]interface{}{
		"codes": []int{16, 9, 10, 11, 12, 13, 15},
		"userInfo": map[string]interface{}{
			"username":   username,
			"headImgUrl": "/public/logo.svg",
		},
		"menuList": []interface{}{},
		"roles":    []string{"admin"},
		"version":  config.Version,
	})
}

// UpdatePasswd updates user password
func (h *APIHandler) UpdatePasswd(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Username    string `json:"username"`
		Password    string `json:"password"`
		NewPassword string `json:"newpassword"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		RespondAPIError(w, 500, "Invalid request")
		return
	}

	// Check minimum password length (original uses 7, message says 8)
	if len(req.NewPassword) < 7 {
		RespondAPIError(w, 500, "password too short, at less 8 digits")
		return
	}

	if err := h.userDAO.Validate(req.Username, req.Password); err != nil {
		RespondAPIError(w, 500, "password error")
		return
	}

	if err := h.userDAO.UpdatePassword(req.Username, req.NewPassword); err != nil {
		RespondAPIError(w, 500, err.Error())
		return
	}

	RespondSuccessMsg(w, "update success")
}

// UpdateUsername updates user username
func (h *APIHandler) UpdateUsername(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Username    string `json:"username"`
		Password    string `json:"password"`
		NewUsername string `json:"newusername"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		RespondAPIError(w, 500, "Invalid request")
		return
	}

	if len(req.NewUsername) < 3 {
		RespondAPIError(w, 500, "username too short, at least 3 characters")
		return
	}

	if err := h.userDAO.Validate(req.Username, req.Password); err != nil {
		RespondAPIError(w, 500, "password error")
		return
	}

	// Delete old user and create new one with same password
	if err := h.userDAO.Delete(req.Username); err != nil {
		RespondAPIError(w, 500, err.Error())
		return
	}

	if err := h.userDAO.Create(req.NewUsername, req.Password); err != nil {
		RespondAPIError(w, 500, err.Error())
		return
	}

	RespondSuccessMsg(w, "update success")
}

// GetAlistConfig returns Alist server configuration
func (h *APIHandler) GetAlistConfig(w http.ResponseWriter, r *http.Request) {
	RespondSuccess(w, h.cfg.AlistServer)
}

// SaveAlistConfig saves Alist server configuration
func (h *APIHandler) SaveAlistConfig(w http.ResponseWriter, r *http.Request) {
	var raw map[string]interface{}
	if err := json.NewDecoder(r.Body).Decode(&raw); err != nil {
		RespondAPIError(w, 500, "Invalid request: "+err.Error())
		return
	}
	if _, hasLegacy := raw["rangeCompatTtlMinutes"]; hasLegacy {
		if atomic.CompareAndSwapUint32(&deprecatedRangeCompatTTLWarned, 0, 1) {
			log.Warn().
				Str("remote_addr", r.RemoteAddr).
				Str("user_agent", r.UserAgent()).
				Msg("Deprecated config key 'rangeCompatTtlMinutes' received from client; please upgrade to 'rangeReprobeMinutes'")
		}
		RespondAPIError(w, 500, "rangeCompatTtlMinutes is deprecated, use rangeReprobeMinutes")
		return
	}

	server := config.ParseAlistServerFromMap(raw)

	if err := h.cfg.UpdateAlistServer(server); err != nil {
		RespondAPIError(w, 500, err.Error())
		return
	}

	RespondSuccessMsg(w, "save ok")
}

// GetWebdavConfig returns WebDAV server configurations
func (h *APIHandler) GetWebdavConfig(w http.ResponseWriter, r *http.Request) {
	RespondSuccess(w, h.cfg.WebDAVServer)
}

// SaveWebdavConfig adds a new WebDAV server configuration
func (h *APIHandler) SaveWebdavConfig(w http.ResponseWriter, r *http.Request) {
	var raw map[string]interface{}
	if err := json.NewDecoder(r.Body).Decode(&raw); err != nil {
		RespondAPIError(w, 500, "Invalid request: "+err.Error())
		return
	}

	server := config.ParseWebDAVServerFromMap(raw)

	// Generate ID
	id := make([]byte, 16)
	rand.Read(id)
	server.ID = hex.EncodeToString(id)

	if err := h.cfg.AddWebDAVServer(server); err != nil {
		RespondAPIError(w, 500, err.Error())
		return
	}

	RespondSuccess(w, h.cfg.WebDAVServer)
}

// UpdateWebdavConfig updates a WebDAV server configuration
func (h *APIHandler) UpdateWebdavConfig(w http.ResponseWriter, r *http.Request) {
	var raw map[string]interface{}
	if err := json.NewDecoder(r.Body).Decode(&raw); err != nil {
		RespondAPIError(w, 500, "Invalid request: "+err.Error())
		return
	}

	server := config.ParseWebDAVServerFromMap(raw)

	if err := h.cfg.UpdateWebDAVServer(server); err != nil {
		RespondAPIError(w, 500, err.Error())
		return
	}

	RespondSuccess(w, h.cfg.WebDAVServer)
}

// DelWebdavConfig deletes a WebDAV server configuration
func (h *APIHandler) DelWebdavConfig(w http.ResponseWriter, r *http.Request) {
	var req struct {
		ID string `json:"id"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		RespondAPIError(w, 500, "Invalid request")
		return
	}

	if err := h.cfg.DeleteWebDAVServer(req.ID); err != nil {
		RespondAPIError(w, 500, err.Error())
		return
	}

	RespondSuccess(w, h.cfg.WebDAVServer)
}

// EncodeFoldName encodes folder name with password
func (h *APIHandler) EncodeFoldName(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Password      string `json:"password"`
		EncType       string `json:"encType"`
		FolderPasswd  string `json:"folderPasswd"`
		FolderEncType string `json:"folderEncType"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		RespondAPIError(w, 500, "Invalid request")
		return
	}

	folderNameEnc := encryption.EncodeFolderName(req.Password, req.EncType, req.FolderPasswd, req.FolderEncType)
	RespondSuccess(w, map[string]interface{}{
		"folderNameEnc": folderNameEnc,
	})
}

// DecodeFoldName decodes folder name
func (h *APIHandler) DecodeFoldName(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Password      string `json:"password"`
		EncType       string `json:"encType"`
		FolderNameEnc string `json:"folderNameEnc"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		RespondAPIError(w, 500, "Invalid request")
		return
	}

	folderEncType, folderPasswd, ok := encryption.DecodeFolderName(req.Password, req.EncType, req.FolderNameEnc)
	if !ok {
		RespondAPIError(w, 500, "folderName is error")
		return
	}

	RespondSuccess(w, map[string]interface{}{
		"folderEncType": folderEncType,
		"folderPasswd":  folderPasswd,
	})
}

// GetSchemeConfig returns server scheme configuration
func (h *APIHandler) GetSchemeConfig(w http.ResponseWriter, r *http.Request) {
	RespondSuccess(w, h.cfg.Scheme)
}

// SaveSchemeConfig saves scheme configuration
// Returns needRestart: true if server restart is required
func (h *APIHandler) SaveSchemeConfig(w http.ResponseWriter, r *http.Request) {
	var scheme config.SchemeConfig
	if err := json.NewDecoder(r.Body).Decode(&scheme); err != nil {
		RespondAPIError(w, 500, "Invalid request: "+err.Error())
		return
	}

	needRestart, err := h.cfg.UpdateScheme(scheme)
	if err != nil {
		RespondAPIError(w, 500, err.Error())
		return
	}

	RespondSuccess(w, map[string]interface{}{
		"message":     "save ok",
		"needRestart": needRestart,
	})

	// Trigger restart asynchronously if needed
	if needRestart {
		go func() {
			time.Sleep(100 * time.Millisecond) // Let response complete
			restart.Trigger()
		}()
	}
}

// ExportFileMeta exports file metadata from MySQL for external sync
func (h *APIHandler) ExportFileMeta(w http.ResponseWriter, r *http.Request) {
	if h.mysqlStore == nil {
		RespondAPIError(w, 500, "mysql not enabled")
		return
	}

	limit := 1000
	offset := 0
	if v := r.URL.Query().Get("limit"); v != "" {
		if parsed, err := strconv.Atoi(v); err == nil && parsed > 0 {
			if parsed > 5000 {
				parsed = 5000
			}
			limit = parsed
		}
	}
	if v := r.URL.Query().Get("offset"); v != "" {
		if parsed, err := strconv.Atoi(v); err == nil && parsed >= 0 {
			offset = parsed
		}
	}

	var updatedAfter time.Time
	if v := r.URL.Query().Get("since"); v != "" {
		if parsed, err := strconv.ParseInt(v, 10, 64); err == nil && parsed > 0 {
			updatedAfter = time.Unix(parsed, 0)
		}
	}
	if updatedAfter.IsZero() {
		if v := r.URL.Query().Get("updated_after"); v != "" {
			if t, err := time.Parse(time.RFC3339, v); err == nil {
				updatedAfter = t
			}
		}
	}

	filter := mysqlstore.FileMetaFilter{
		ProviderHost: r.URL.Query().Get("provider"),
		OriginalPath: r.URL.Query().Get("path"),
		PathPrefix:   r.URL.Query().Get("path_prefix"),
		UpdatedAfter: updatedAfter,
		CursorKey:    r.URL.Query().Get("cursor"),
		Limit:        limit,
		Offset:       offset,
	}

	records, err := h.mysqlStore.ListFileMeta(r.Context(), filter)
	if err != nil {
		RespondAPIError(w, 500, err.Error())
		return
	}

	var maxUpdated time.Time
	nextCursor := ""
	for _, record := range records {
		if record.UpdatedAt.After(maxUpdated) {
			maxUpdated = record.UpdatedAt
		}
		nextCursor = record.KeyHash
	}
	nextSince := int64(0)
	nextSinceRFC3339 := ""
	if !maxUpdated.IsZero() {
		nextSince = maxUpdated.Unix()
		nextSinceRFC3339 = maxUpdated.UTC().Format(time.RFC3339)
	}

	RespondSuccess(w, map[string]interface{}{
		"items":              records,
		"limit":              limit,
		"offset":             offset,
		"has_more":           len(records) == limit,
		"next_since":         nextSince,
		"next_since_rfc3339": nextSinceRFC3339,
		"next_cursor":        nextCursor,
	})
}

// GetProxyDomainDictionary returns cached proxy provider dictionary.
func (h *APIHandler) GetProxyDomainDictionary(w http.ResponseWriter, r *http.Request) {
	if h.dictMgr == nil {
		RespondAPIError(w, 500, "proxy dictionary not initialized")
		return
	}
	dict, err := h.dictMgr.LoadOrRefresh()
	if err != nil {
		RespondAPIError(w, 500, err.Error())
		return
	}
	RespondSuccess(w, dict)
}

// RefreshProxyDomainDictionary rescans OpenList and refreshes dictionary.
func (h *APIHandler) RefreshProxyDomainDictionary(w http.ResponseWriter, r *http.Request) {
	if h.dictMgr == nil {
		RespondAPIError(w, 500, "proxy dictionary not initialized")
		return
	}
	dict, err := h.dictMgr.Refresh()
	if err != nil {
		RespondAPIError(w, 500, err.Error())
		return
	}
	RespondSuccess(w, dict)
}

// GetProxyRoutingConfig returns current proxy configuration.
func (h *APIHandler) GetProxyRoutingConfig(w http.ResponseWriter, r *http.Request) {
	RespondSuccess(w, h.cfg.Proxy)
}

func (h *APIHandler) buildRulesFromSelection(proxyCfg *config.ProxyConfig) {
	if proxyCfg == nil || len(proxyCfg.SelectedProviderIDs) == 0 || h.dictMgr == nil {
		return
	}
	dict, err := h.dictMgr.LoadOrRefresh()
	if err != nil || dict == nil {
		return
	}
	selected := make(map[string]struct{}, len(proxyCfg.SelectedProviderIDs))
	for _, id := range proxyCfg.SelectedProviderIDs {
		item := strings.ToLower(strings.TrimSpace(id))
		if item != "" {
			selected[item] = struct{}{}
		}
	}
	domainSet := make(map[string]struct{})
	priority := 100
	rules := make([]config.ProxyRule, 0, 128)
	for _, provider := range dict.Providers {
		if _, ok := selected[strings.ToLower(provider.ID)]; !ok {
			continue
		}
		for _, domain := range provider.Domains {
			domain = strings.ToLower(strings.TrimSpace(domain))
			if domain == "" {
				continue
			}
			if _, ok := domainSet[domain]; ok {
				continue
			}
			domainSet[domain] = struct{}{}
			rules = append(rules, config.ProxyRule{
				ID:         provider.ID + "-" + domain,
				ProviderID: provider.ID,
				MatchType:  "domain_suffix",
				Pattern:    domain,
				Action:     "proxy",
				Enabled:    true,
				Priority:   priority,
			})
			priority++
		}
	}
	if len(rules) > 0 {
		proxyCfg.Rules = rules
	}
	if len(domainSet) > 0 {
		domains := make([]string, 0, len(domainSet))
		for domain := range domainSet {
			domains = append(domains, domain)
		}
		proxyCfg.SelectedDomains = domains
	}
}

// SaveProxyRoutingConfig saves current proxy config.
func (h *APIHandler) SaveProxyRoutingConfig(w http.ResponseWriter, r *http.Request) {
	var proxyCfg config.ProxyConfig
	if err := json.NewDecoder(r.Body).Decode(&proxyCfg); err != nil {
		RespondAPIError(w, 500, "Invalid request: "+err.Error())
		return
	}
	if proxyCfg.Mode == "rules" && len(proxyCfg.Rules) == 0 && len(proxyCfg.SelectedProviderIDs) > 0 {
		h.buildRulesFromSelection(&proxyCfg)
	}
	if err := h.cfg.UpdateProxy(proxyCfg); err != nil {
		RespondAPIError(w, 500, err.Error())
		return
	}
	RespondSuccessMsg(w, "save ok")
}
